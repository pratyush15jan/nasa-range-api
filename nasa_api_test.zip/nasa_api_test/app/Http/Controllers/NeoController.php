<?php

namespace App\Http\Controllers;

use App\Neo;
use Illuminate\Http\Request;

class NeoController extends Controller
{
    /**
     * The default application route '/'.
     * 
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return response()->json([
            'hello' => 'world',
        ], 200);
    }

    /**
     * Show a paginated list of all hazardous Neos from the DB.
     * 
     * @return \Illuminate\Http\Response
     */
    public function showHazardous(Request $request)
    {
        $from = '2020-07-09';
        $to = '2020-07-10';
        return Neo::whereBetween('date',[$from, $to])->paginate(15);
    }

    /**
     * Show the fastest NEO from the DB.
     * 
     * @param  \Illuminate\Http\Request $request
     * @return \Illuminate\Http\Response
     */
    public function showFastest(Request $request)
    {

        return Neo::whereIsHazardous(true)->orderByDesc('speed')->first();
    }


}
